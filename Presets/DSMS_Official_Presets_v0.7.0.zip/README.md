# DSMS Official Presets v0.7.0

This archive contains the official base-game and DLC JSON presets for
DSMS ModLoader v0.7.0.

## Installation

1. Install DSMS ModLoader first.
2. Close the game.
3. Extract this archive directly into the main DragonSword Awakening game
   directory—the directory that already contains the `DS` folder.
4. Keep the included folder structure unchanged.
5. Press `F6` in game if DSMS is already running, or restart the game.

Presets are installed under:

```text
DS\Content\Paks\~mods\HMV_DS_SELECTOR\_BASEGAME\
DS\Content\Paks\~mods\HMV_DS_SELECTOR\_DLC\
```

The private `HoverModsVault` presets and the `_EXAMPLES` documentation are not
included in this release.

`SHA256SUMS.txt` contains the SHA-256 fingerprint of every distributed file.

